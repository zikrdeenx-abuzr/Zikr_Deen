/* Adds the azan sound + permissions to the generated android project. Safe to run many times. */
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..'),app=path.join(root,'android','app','src','main');
if(!fs.existsSync(app)){console.error('android folder nahi mila — pehle: npx cap add android');process.exit(1)}
// 1) azan sound for the notification channel
const raw=path.join(app,'res','raw');fs.mkdirSync(raw,{recursive:true});
fs.copyFileSync(path.join(root,'native','azan.mp3'),path.join(raw,'azan.mp3'));
console.log('azan.mp3 -> res/raw');
// 2) permissions
const mf=path.join(app,'AndroidManifest.xml');let x=fs.readFileSync(mf,'utf8');
const need=['android.permission.POST_NOTIFICATIONS','android.permission.SCHEDULE_EXACT_ALARM','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.VIBRATE','android.permission.WAKE_LOCK'];
let add='';need.forEach(p=>{if(!x.includes(p))add+='    <uses-permission android:name="'+p+'" />\n'});
if(add){x=x.replace(/(\s*)<\/manifest>/,'\n'+add+'</manifest>');fs.writeFileSync(mf,x);console.log('permissions added')}else console.log('permissions already present');
