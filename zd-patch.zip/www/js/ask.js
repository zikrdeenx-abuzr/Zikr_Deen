/* Zikr Deen App — "Ask Zikr Deen": Islamic Q&A chatbot (Gemini + Google Search). */
(function(){'use strict';
const ZD=window.ZD,$=ZD.$,esc=ZD.esc,icon=ZD.icon,R=ZD.R;
const CFG=window.ZD_ASK||{};
const HKEY='zdAskChat';
const SYSTEM=`You are "Ask Zikr Deen", a careful Islamic knowledge assistant inside the Zikr Deen app.

RULES
1. Answer from the Quran and authentic Sunnah, following the understanding of Ahl as-Sunnah wal-Jamaah. Use web search to verify every ayah, hadith and ruling before answering. Prefer reliable sources: quran.com, sunnah.com, islamqa.info, dorar.net, Darul Uloom / Al-Azhar / Dar al-Ifta websites, Islamweb.
2. Quran: give Surah name and number, e.g. (Al-Baqarah 2:255), with the Arabic text and a short translation. Hadith: give collection and number, e.g. (Sahih al-Bukhari 1), and the grading (sahih / hasan / da'if) when known. NEVER invent or guess an ayah, hadith, narrator or reference. If you cannot verify it, say so clearly.
3. For fiqh questions where scholars differ, state the main views (Hanafi, Maliki, Shafi'i, Hanbali) fairly and without sectarian attack. Do not make takfir or insult any group.
4. You are not a mufti. For serious personal matters (talaq, inheritance, major financial contracts, medical-religious decisions) give the general ruling and advise asking a qualified local scholar.
5. Reply in the SAME language and script as the user: Hindi (Devanagari), Hinglish, Urdu, or English. Keep answers short, clear and kind: first a direct answer, then the evidence, then a brief practical note.
6. If the question is not about Islam, answer briefly and politely and guide back to Islamic topics. Refuse anything harmful, hateful or sectarian.
7. End religious rulings with "Wallahu a'lam" (Allah knows best).

APP GUIDE (use this when the user asks where something is in the Zikr Deen app, or how to do something in it)
The app has 6 bottom tabs: Home, Quran, Learn, Al-Mulk, Ask AI, More. When you point to a place, give the path in words AND a tappable link in the form [Name](#/route). Only use routes listed here.
- Home [Home](#/home): Aaj ki Ayah (Al-Mulk) with listen/share, namaz timing card, daily reading goal, streak, Ask Zikr Deen card, Learn folders, Go to ayah, Saved.
- Quran tab [Quran](#/surahs): all 114 surahs (read or listen). Juz index and Mushaf: [Juz index](#/juz). Open any ayah: Home or Quran > "Go to ayah" (e.g. 67:15). Bookmarks: [Saved](#/bookmarks).
- Surah Al-Mulk hifz hub (learn, lab, revision, listening): [Al-Mulk](#/mulk).
- Learn tab [Learn](#/folders) has folders: [Ayah by Ayah](#/learn), [Namaz (steps, rakats, what to recite)](#/namaz), [Mukammal Namaz - word by word, Arabic, Roman, Hinglish tarjuma, 22 hisse](#/nz), [Daily Azkaar - subah-shaam, namaz ke baad, roz-marra duaein](#/azkaar), [Hadith - Bukhari, Muslim, Abu Dawud, Tirmidhi, Nasa'i, Ibn Majah with Arabic, Urdu, English, AI Hinglish](#/hadith), [Repeat](#/repeat), [Puzzles](#/puzzle), [Revision](#/revision), [Start here](#/path).
- Namaz timings and Azan: More tab > "Namaz Timings & Azan" [Namaz Timings](#/prayer) (city setting, azan at prayer time, reminders).
- More tab [More](#/more): appearance (theme, text size), reading and listening settings, offline library (download surahs for offline), backup and restore, about.
- Specific places: Wudu ka tareeqa = Mukammal Namaz > Hissa 2 [Hissa 2](#/nsec/2). Azaan aur jawab = [Hissa 4](#/nsec/4). Namaz ka mukammal tareeqa = [Hissa 5](#/nsec/5). Witr/Qunoot = [Hissa 7](#/nsec/7). Namaz ke baad ke azkaar = [Hissa 8](#/nsec/8) and [Hissa 13](#/nsec/13). Janaza = [Hissa 11](#/nsec/11). Subah-Shaam azkaar = [Hissa 14](#/nsec/14). Roz-marra duaein = [Hissa 16](#/nsec/16). Quran ki duaein = [Hissa 17](#/nsec/17), [Hissa 21](#/nsec/21); Ambiya ki duaein = [Hissa 18](#/nsec/18). "Kab kaun si dua" list = [Hissa 22](#/nsec/22). Searching a dua: open Mukammal Namaz and use the search box.
- If the user asks for something the app does not have, say so honestly and suggest the closest place.
If the user asks "app me kya kya hai", give a short, organised tour of the above.`;

const STARTERS=['App me Hadith kahan milegi?','Wudu ka tareeqa app me kahan hai?','Subah-shaam ke azkaar kahan hain?','Namaz me bhool jaaye to sajda sahw kab?','Zakat kis par farz hai?','App me kya kya features hain?'];

function load(){try{return JSON.parse(localStorage.getItem(HKEY)||'[]')}catch(e){return[]}}
function save(h){try{localStorage.setItem(HKEY,JSON.stringify(h.slice(-40)))}catch(e){}}

/* ---------- tiny markdown -> safe HTML ---------- */
function md(t){
  let s=esc(t);
  s=s.replace(/\[([^\]\n]{1,80})\]\((#\/[a-z0-9\/_-]*)\)/gi,'<a class="ask-link" href="$2">$1</a>').replace(/\[([^\]\n]{1,80})\]\((https:\/\/[^\s)]+)\)/gi,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  s=s.replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/(^|[^*])\*([^*\n]+)\*/g,'$1<i>$2</i>');
  s=s.replace(/([\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF][\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF\s\u064B-\u0652\u06D6-\u06ED،؟.]*)/g,m=>'<span class="ar ask-ar" lang="ar">'+m.trim()+'</span> ');
  const lines=s.split('\n'),out=[];let inList=false;
  for(const ln of lines){
    const m=ln.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
    if(m){if(!inList){out.push('<ul>');inList=true}out.push('<li>'+m[1]+'</li>')}
    else{if(inList){out.push('</ul>');inList=false}out.push(ln.trim()?'<p>'+ln+'</p>':'')}
  }
  if(inList)out.push('</ul>');
  return out.join('');
}

/* ---------- Gemini call ---------- */
function toContents(h){return h.filter(m=>m.t).slice(-12).map(m=>({role:m.r==='u'?'user':'model',parts:[{text:m.t}]}))}
async function callGemini(model,contents,grounded,sys){
  const body={systemInstruction:{parts:[{text:sys||SYSTEM}]},contents,generationConfig:{temperature:.3,maxOutputTokens:3000}};
  if(grounded)body.tools=[{google_search:{}}];
  let url,headers={'Content-Type':'application/json'};
  if(CFG.proxy){url=CFG.proxy;body.model=model}
  else{url='https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent';headers['x-goog-api-key']=CFG.key}
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),grounded?30000:75000);
  try{
    const r=await fetch(url,{method:'POST',headers,body:JSON.stringify(body),signal:ctl.signal});
    const j=await r.json().catch(()=>({}));
    if(!r.ok){const e=new Error((j.error&&j.error.message)||('HTTP '+r.status));e.status=r.status;throw e}
    return j;
  }finally{clearTimeout(to)}
}
function parse(j){
  const c=(j.candidates||[])[0];if(!c)throw new Error('empty');
  const text=((c.content&&c.content.parts)||[]).map(p=>p.text||'').join('').trim();
  if(!text)throw new Error('empty');
  const seen={},src=[];
  (((c.groundingMetadata||{}).groundingChunks)||[]).forEach(g=>{const w=g.web;if(w&&w.uri&&!seen[w.uri]){seen[w.uri]=1;src.push({u:w.uri,t:w.title||w.uri})}});
  return{text,src:src.slice(0,5)};
}
async function ask(history,noSearch,sys){
  if(!CFG.proxy&&(!CFG.key||CFG.key.indexOf('__')===0)){const e=new Error('nokey');e.nokey=true;throw e}
  const contents=toContents(history);let last;
  for(const model of (CFG.models||['gemini-2.5-flash'])){
    for(const grounded of (noSearch?[false]:[true,false])){
      try{return parse(await callGemini(model,contents,grounded,sys))}
      catch(e){last=e;if(e.status===401||e.status===403&&!grounded){if(e.status===401)throw e}
        if(e.name==='AbortError'||/Failed to fetch|NetworkError|Load failed/i.test(e.message)){e.offline=true;if(!grounded)throw e}}
    }
  }
  throw last;
}
function friendly(e){
  const dbg=' [Detail: '+(e.status||e.name||'error')+' — '+String(e.message||'').slice(0,90)+']';
  return friendly0(e)+(e.nokey?'':dbg);
}
function friendly0(e){
  if(e.nokey)return'AI abhi set nahi hai. App banane wale ko GitHub me GEMINI_API_KEY secret add karna hoga.';
  if(e.offline)return'Internet nahi mil raha ya jawab aane me der lagi. Connection check karke dobara try karein.';
  if(e.status===429)return'Abhi bahut zyada sawal aa rahe hain (free limit). Thodi der baad dobara try karein.';
  if(e.status===400||e.status===401||e.status===403)return'AI key me masla hai. App banane wale se kahein ki Gemini API key check karein.';
  return'Jawab nahi mil saka. Thodi der baad dobara try karein.';
}

ZD.askOnce=async function(prompt,sys){const a=await ask([{r:'u',t:prompt}],true,sys);return a.text};

/* ---------- view ---------- */
function bubble(m){
  if(m.r==='u')return'<div class="ask-m u"><div class="ask-b">'+esc(m.t).replace(/\n/g,'<br>')+'</div></div>';
  const src=(m.s&&m.s.length)?'<div class="ask-src"><span>Sources</span>'+m.s.map(x=>'<a href="'+esc(x.u)+'" target="_blank" rel="noopener noreferrer">'+esc(x.t)+'</a>').join('')+'</div>':'';
  return'<div class="ask-m a"><div class="ask-b'+(m.e?' err':'')+'">'+(m.e?esc(m.t):md(m.t))+src+
    (m.e?'':'<button class="ask-cp" data-cp aria-label="Copy answer">'+icon('copy')+'</button>')+'</div></div>';
}
R.ask=async function(){
  let hist=load(),busy=false;
  const v=$('#view');
  v.innerHTML='<header class="topbar"><h1>Ask Zikr Deen<span class="sub">Islamic sawal-jawab · Quran, Hadith & web se</span></h1>'+
   '<button class="ibtn" id="askClr" aria-label="Clear chat">'+icon('trash')+'</button></header>'+
   '<main class="ask"><div id="askList"></div>'+
   '<p class="ask-note">AI se galti ho sakti hai. Zaroori masail me kisi aalim se zaroor poochein.</p>'+
   '<form class="ask-bar" id="askForm"><textarea id="askIn" rows="1" placeholder="Apna sawal likhein…" aria-label="Your question" maxlength="800"></textarea>'+
   '<button class="ask-send" id="askSend" aria-label="Send" type="submit">'+icon('send')+'</button></form></main>';
  const list=$('#askList'),inp=$('#askIn'),send=$('#askSend');
  const draw=()=>{
    if(!hist.length){list.innerHTML='<div class="ask-hello card"><div class="ask-logo">'+icon('ask')+'</div><h2 class="h2" style="margin:0 0 4px">Assalamu Alaikum 👋</h2><p class="muted small" style="margin:0 0 12px">Islam, Quran, Hadith, namaz, roza, zakat — koi bhi sawal poochein. Jawab Quran, sahih Hadith aur bharosemand websites se check karke diya jata hai.</p><div class="ask-chips">'+STARTERS.map(s=>'<button type="button" class="ask-chip" data-q="'+esc(s)+'">'+esc(s)+'</button>').join('')+'</div></div>'}
    else list.innerHTML=hist.map(bubble).join('');
  };
  const down=()=>setTimeout(()=>{const f=$('#askForm');if(f)f.scrollIntoView({block:'end',behavior:'smooth'})},30);
  const fit=()=>{inp.style.height='auto';inp.style.height=Math.min(120,inp.scrollHeight)+'px'};
  async function go(q){
    q=(q||'').trim();if(!q||busy)return;busy=true;send.disabled=true;
    hist.push({r:'u',t:q});inp.value='';fit();draw();
    list.insertAdjacentHTML('beforeend','<div class="ask-m a" id="askTyp"><div class="ask-b"><span class="ask-dots"><i></i><i></i><i></i></span> <span class="muted small">Check kar raha hoon…</span></div></div>');down();
    try{const a=await ask(hist);hist.push({r:'a',t:a.text,s:a.src})}
    catch(e){console.error(e);hist.push({r:'a',t:friendly(e),e:1})}
    save(hist.filter(m=>!m.e));busy=false;send.disabled=false;if(!$('#askList'))return;draw();down();
  }
  $('#askForm').addEventListener('submit',e=>{e.preventDefault();go(inp.value)});
  inp.addEventListener('input',fit);
  inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!/Android|iPhone/i.test(navigator.userAgent)){e.preventDefault();go(inp.value)}});
  list.addEventListener('click',e=>{
    const c=e.target.closest('[data-q]');if(c){go(c.dataset.q);return}
    const cp=e.target.closest('[data-cp]');if(cp){const b=cp.closest('.ask-b');ZD.copy(b.innerText.replace(/\n?Sources[\s\S]*$/,'').trim())}
  });
  $('#askClr').addEventListener('click',()=>{if(!hist.length)return;if(confirm('Poori chat saaf kar dein?')){hist=[];save(hist);draw()}});
  draw();if(hist.length)down();
  try{const pre=sessionStorage.getItem('zdAskPre');if(pre){sessionStorage.removeItem('zdAskPre');inp.value=pre;fit();inp.focus()}}catch(_){}
};

/* home screen card */
ZD.askHTML=()=>'<section class="block"><a class="card ask-card" href="#/ask">'+
  '<div class="ask-logo">'+icon('ask')+'</div><div style="flex:1;min-width:0"><div style="font-size:19px;font-weight:600">Ask Zikr Deen</div>'+
  '<div class="muted small">Islam, Quran ya Hadith ka koi bhi sawal — AI se poochein</div></div>'+icon('back','ask-arr')+'</a></section>';
})();
