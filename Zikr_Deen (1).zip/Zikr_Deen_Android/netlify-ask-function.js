// OPTIONAL (zyada safe): isse API key APK me nahi, Netlify server par rehti hai.
// 1) Apni Netlify site ke repo me ye file rakhein:  netlify/functions/ask.js
// 2) Netlify > Site settings > Environment variables: GEMINI_API_KEY = aapki key
// 3) www/js/ask-config.js me proxy:'https://APKI-SITE.netlify.app/.netlify/functions/ask' likhein
exports.handler = async (event) => {
  const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: cors, body: '' };
  try {
    const body = JSON.parse(event.body || '{}');
    const model = String(body.model || 'gemini-flash-latest').replace(/[^a-zA-Z0-9.\-]/g, '');
    delete body.model;
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
      body: JSON.stringify(body)
    });
    return { statusCode: r.status, headers: { ...cors, 'Content-Type': 'application/json' }, body: await r.text() };
  } catch (e) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: { message: String(e) } }) };
  }
};
