/* Zikr Deen App — Hadith folder: offline download (Arabic + Urdu + English), Hinglish tarjuma (AI, saved on phone). */
(function(){'use strict';
const ZD=window.ZD,$=ZD.$,esc=ZD.esc,icon=ZD.icon,R=ZD.R;
const view=()=>$('#view');
const top=(t,sub)=>'<header class="topbar"><button class="ibtn" data-act="back" aria-label="Back">'+icon('back')+'</button><h1>'+esc(t)+(sub?'<span class="sub">'+esc(sub)+'</span>':'')+'</h1></header>';
/* id, name (as in the app list), author, arabic, sections, api-available */
const BOOKS=[
 ['bukhari','Al-Bukhari','Imam Bukhari','صحيح البخاري',97,1],['muslim','Al-Muslim','Imam Muslim','صحيح مسلم',56,1],
 ['tirmidhi','Al-Tirmizi','Imam Tirmidhi','جامع الترمذي',49,1],['abudawud','Abu Dawood','Imam Abu Dawud','سنن أبي داود',43,1],
 ['nasai','Al-Nasai',"Imam Nasa'i",'سنن النسائي',51,1],['ibnmajah','Sunnan e Ibn e Maja','Imam Ibn Majah','سنن ابن ماجه',37,1],
 ['silsila','Al-Silsila','Shaikh Albani','السلسلة الصحيحة',0,0],['ahmad','Musnad Ahmed','Imam Ahmad','مسند أحمد',0,0]];
const bk=id=>BOOKS.find(b=>b[0]===id);
const BASES=['https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/','https://raw.githubusercontent.com/fawazahmed0/hadith-api/1/'];
/* ---------- storage (IndexedDB: big files + saved Hinglish) ---------- */
let dbp=null;
function db(){if(!dbp)dbp=new Promise((res,rej)=>{try{const r=indexedDB.open('zd-hadith',1);r.onupgradeneeded=()=>{const d=r.result;d.createObjectStore('ed');d.createObjectStore('hi')};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}catch(e){rej(e)}});return dbp}
async function idb(store,mode,fn){const d=await db();return new Promise((res,rej)=>{const t=d.transaction(store,mode),s=t.objectStore(store),q=fn(s);t.oncomplete=()=>res(q&&q.result);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error)})}
const idbGet=(st,k)=>idb(st,'readonly',s=>s.get(k)).catch(()=>undefined);
const idbSet=(st,k,v)=>idb(st,'readwrite',s=>s.put(v,k));
const idbDel=(st,k)=>idb(st,'readwrite',s=>s.delete(k));
/* ---------- offline editions ---------- */
const mem={};
async function local(ed){if(mem[ed])return mem[ed];const r=await idbGet('ed',ed);if(r){r.idx=null;mem[ed]=r}return r||null}
function bySec(L){if(L.idx)return L.idx;const m={};L.h.forEach(x=>{(m[x[2]]=m[x[2]]||[]).push(x)});return L.idx=m}
async function offline(id){const [a,u,e]=await Promise.all(['ara-','urd-','eng-'].map(p=>local(p+id)));return a&&u&&e?{a,u,e}:null}
async function fetchJSON(path,onProg){
  let err;
  for(const base of BASES)for(const ext of ['.min.json','.json']){
    try{
      const r=await fetch(base+path+ext);if(!r.ok){err=new Error('HTTP '+r.status);continue}
      const total=Number(r.headers.get('content-length'))||0;
      if(!r.body||!r.body.getReader||!onProg){return await r.json()}
      const rd=r.body.getReader(),parts=[];let got=0;
      for(;;){const {done,value}=await rd.read();if(done)break;parts.push(value);got+=value.length;onProg(got,total)}
      const buf=new Uint8Array(got);let o=0;parts.forEach(p=>{buf.set(p,o);o+=p.length});
      return JSON.parse(new TextDecoder('utf-8').decode(buf));
    }catch(e){err=e}
  }
  throw err||new Error('fail');
}
async function download(id,onStat){
  const eds=['ara-','urd-','eng-'];let size=0;
  for(let i=0;i<eds.length;i++){
    const ed=eds[i]+id,nm=['Arabic','Urdu','English'][i];
    onStat(nm+' ('+(i+1)+'/3) download ho raha hai…');
    const j=await fetchJSON('editions/'+ed,(g,t)=>onStat(nm+' ('+(i+1)+'/3) · '+(g/1048576).toFixed(1)+' MB'+(t?' / '+(t/1048576).toFixed(1)+' MB':'')));
    const secs={};const ms=j.metadata&&j.metadata.section;if(ms)for(const k in ms)secs[k]=ms[k];
    const h=(j.hadiths||[]).map(x=>[x.hadithnumber,x.text||'',x.reference&&x.reference.book!=null?x.reference.book:0,(x.grades||[]).map(g=>g.grade).filter(Boolean).join(' · ')]);
    if(!h.length)throw new Error('empty');
    size+=JSON.stringify(h).length;
    await idbSet('ed',ed,{id:ed,secs,h,at:Date.now()});delete mem[ed];
  }
  return size;
}
async function removeOffline(id){for(const p of['ara-','urd-','eng-']){await idbDel('ed',p+id);delete mem[p+id]}}
/* ---------- online fallback (single section) ---------- */
const cache={};
async function api(path){if(cache[path])return cache[path];const j=await fetchJSON(path);cache[path]=j;return j}
/* ---------- Hinglish (AI) — saved on phone ---------- */
const HSYS='You translate Islamic hadith into simple Hinglish (Hindi-Urdu written in Roman letters, easy for everyday Indian readers). Be faithful to the meaning; do not add commentary, explanation or extra hadith. Keep "Allah", "Nabi ﷺ", "Rasulullah ﷺ", names of Sahaba with "(RA)". Output exactly what is asked and nothing else.';
const hiKey=(b,n)=>b+':'+n;
const hiMem={};
async function hiGet(b,n){const k=hiKey(b,n);if(hiMem[k])return hiMem[k];const v=await idbGet('hi',k);if(v)hiMem[k]=v;return v||''}
async function hiSet(b,n,t){hiMem[hiKey(b,n)]=t;try{await idbSet('hi',hiKey(b,n),t)}catch(e){}}
function parseArr(t,n){
  t=String(t).replace(/```json|```/g,'').trim();const a=t.indexOf('['),z=t.lastIndexOf(']');
  if(a<0||z<0)throw new Error('format');const r=JSON.parse(t.slice(a,z+1));
  if(!Array.isArray(r)||r.length!==n)throw new Error('count');return r.map(x=>String(x).trim());
}
async function translate(book,items){ /* items:[{n,en}] */
  const body=items.map((x,i)=>(i+1)+'. '+x.en.slice(0,1500)).join('\n\n');
  const prompt='Neeche '+items.length+' hadith English me hain. Har ek ka Hinglish tarjuma likho. Sirf ek JSON array of strings do (ek string = ek hadith, wahi order, exactly '+items.length+' strings), koi aur text nahin.\n\n'+body;
  let out,err;
  for(let t=0;t<3;t++){
    try{out=parseArr(await ZD.askOnce(prompt,HSYS),items.length);break}
    catch(e){err=e;if(e.status===429)await new Promise(r=>setTimeout(r,15000*(t+1)));else if(t>=1)break}
  }
  if(!out)throw err||new Error('fail');
  for(let i=0;i<items.length;i++)await hiSet(book,items[i].n,out[i]);
  return out;
}
/* ---------- helpers ---------- */
const LK='zdHdLang';
const getLang=()=>{try{return localStorage.getItem(LK)||'hi'}catch(e){return'hi'}};
const setLang=v=>{try{localStorage.setItem(LK,v)}catch(e){}};
const LANGS=[['hi','Hinglish'],['ur','Urdu'],['en','English']];
const seg=cur=>'<div class="seg" id="hdSeg" role="tablist">'+LANGS.map(([k,l])=>'<button role="tab" aria-selected="'+(k===cur)+'" data-k="'+k+'">'+l+'</button>').join('')+'</div>';
const fail=box=>{box.innerHTML='<div class="empty"><div class="big">📡</div><p><b>Hadith load nahin ho saki.</b></p><p class="small">Internet check karein, ya hub me jaakar is kitaab ko offline download kar lein.</p><button class="btn" id="retry">Dobara try karein</button></div>';$('#retry').addEventListener('click',()=>ZD.route())};
let CUR={};
const nl=t=>esc(t||'');
const fmtMB=n=>(n/1048576).toFixed(0)+' MB';

/* ---------- hub ---------- */
R.hadith=async function(){
  const st={};await Promise.all(BOOKS.filter(b=>b[5]).map(async b=>{st[b[0]]=!!(await offline(b[0]))}));
  if(location.hash.indexOf('#/hadith')!==0)return;
  view().innerHTML=top('Hadith','Kutub-e-Sitta · offline · Hinglish tarjuma')+'<main>'+
   '<p class="muted small" style="margin:0 2px 12px">Kitaab ko ek baar <b>Offline download</b> kar lein (Arabic + Urdu + English) — phir bina internet ke padhein. Hinglish tarjuma AI banata hai aur phone me hamesha ke liye save ho jata hai.</p>'+
   '<form class="card nz-g" id="hdGo" style="display:flex;gap:8px;align-items:center"><select id="hdB" class="sl">'+BOOKS.filter(b=>b[5]).map(b=>'<option value="'+b[0]+'">'+esc(b[1])+'</option>').join('')+'</select><input id="hdN" type="number" min="1" inputmode="numeric" placeholder="Hadith no."><button class="btn sm" type="submit">Kholein</button></form>'+
   BOOKS.map(b=>b[5]?
    '<div class="card hd-bk"><a class="hd-bkh" href="#/hbook/'+b[0]+'"><div style="min-width:0"><b>'+esc(b[1])+'</b><div class="muted small">'+esc(b[2])+' · '+b[4]+' kitaab</div></div><span class="ar" lang="ar">'+b[3]+'</span></a>'+
     '<div class="hd-dl" id="dl_'+b[0]+'">'+(st[b[0]]?'<span class="hd-ok">✓ Offline taiyaar</span><button class="btn sm ghost" data-rm="'+b[0]+'">Hatayein</button>':'<button class="btn sm" data-dl="'+b[0]+'">⬇ Offline download</button>')+'</div></div>':
    '<div class="card hd-bk hd-soon"><div class="hd-bkh"><div style="min-width:0"><b>'+esc(b[1])+'</b><div class="muted small">'+esc(b[2])+' · jald aayegi</div></div><span class="ar" lang="ar">'+b[3]+'</span></div></div>').join('')+
   '<button class="btn" id="dlAll" style="width:100%;margin-top:12px">⬇ Sab 6 kitaabein offline download karein</button><p class="muted small" style="margin:8px 2px">Badi files hain (har kitaab kai MB) — Wi-Fi par karein. Download ke dauran screen on rakhein.</p></main>';
  $('#hdGo').addEventListener('submit',e=>{e.preventDefault();const n=Math.round(Number($('#hdN').value));if(n>0)location.hash='#/hone/'+$('#hdB').value+'/'+n});
  $('#dlAll').addEventListener('click',async e=>{e.target.disabled=true;for(const b of BOOKS.filter(x=>x[5]))if(!st[b[0]]){const ok=await runDl(b[0]);if(!ok)break}R.hadith()});
};
async function runDl(id){
  const box=$('#dl_'+id);if(!box)return false;
  const set=t=>{const b=$('#dl_'+id);if(b)b.innerHTML='<span class="muted small">'+esc(t)+'</span>'};
  try{set('Shuru ho raha hai…');await download(id,set);return true}
  catch(e){console.error(e);const b=$('#dl_'+id);if(b)b.innerHTML='<span class="hd-err">Download fail. Internet/jagah check karein.</span> <button class="btn sm" data-dl="'+id+'">Dobara</button>';return false}
}
document.addEventListener('click',async e=>{
  const d=e.target.closest('[data-dl]');if(d){d.disabled=true;if(await runDl(d.dataset.dl))R.hadith();return}
  const r=e.target.closest('[data-rm]');if(r){if(confirm('Is kitaab ka offline data hata dein?')){await removeOffline(r.dataset.rm);R.hadith()}}
});

/* ---------- kitaab (section) list ---------- */
R.hbook=async function(a){
  const b=bk(a[0]);if(!b||!b[5]){location.hash='#/hadith';return}
  view().innerHTML=top(b[1],b[2])+'<main><p class="muted" style="padding:14px 4px">Load ho raha hai…</p></main>';
  const L=await local('eng-'+b[0])||await local('ara-'+b[0]);
  if(location.hash.indexOf('#/hbook/')!==0)return;
  if(L){
    const idx=bySec(L),keys=Object.keys(L.secs).filter(k=>idx[k]).sort((x,y)=>x-y);
    const ks=keys.length?keys:Object.keys(idx).sort((x,y)=>x-y);
    $('main').innerHTML=ks.map(k=>'<a class="row" href="#/hsec/'+b[0]+'/'+k+'"><span class="num"><span>'+k+'</span></span><div style="flex:1;min-width:0"><b>'+esc(L.secs[k]||('Kitaab '+k))+'</b><div class="muted small">'+idx[k].length+' hadith</div></div>'+icon('back','nz-arr')+'</a>').join('');
  }else{
    let t='';for(let i=1;i<=b[4];i++)t+='<a class="tile" href="#/hsec/'+b[0]+'/'+i+'" style="align-items:center;padding:14px 8px"><b>'+i+'</b><span style="margin:0">Kitaab '+i+'</span></a>';
    $('main').innerHTML='<p class="muted small" style="margin:0 2px 10px">Kitaab ke naam dekhne ke liye is kitaab ko hub me <a href="#/hadith">offline download</a> kar lein.</p><div class="tiles" style="grid-template-columns:repeat(3,1fr)">'+t+'</div>';
  }
};

/* ---------- one hadith card ---------- */
function card(book,h,lang){
  const n=h.n,x=CUR[n];
  let body;
  if(lang==='hi')body='<div class="hd-tr" id="hi_'+n+'">'+(x.hi?nl(x.hi):'<button class="btn sm" data-hi="'+n+'">Hinglish banayein (AI)</button>')+'</div>';
  else body='<div class="hd-tr'+(lang==='ur'?' hd-ur':'')+'">'+nl(lang==='ur'?x.ur:x.en)+'</div>';
  return '<article class="card hd" id="h_'+n+'"><div class="hd-top"><b>'+esc(bk(book)[1])+' · '+n+'</b><span class="muted small">'+esc(x.g||'')+'</span></div>'+
   '<div class="ar hd-ar" lang="ar">'+esc(x.ar)+'</div>'+body+
   '<div class="nz-btns"><button class="btn sm ghost" data-hcp="'+n+'">'+icon('copy')+' Copy</button><button class="btn sm ghost" data-hai="'+n+'">'+icon('ask')+' AI se poochein</button></div></article>'}
document.addEventListener('click',async e=>{
  const c=e.target.closest('[data-hcp]');if(c){const x=CUR[c.dataset.hcp];if(x)ZD.copy(x.ar+'\n\n'+(x.hi||x.en||'')+'\n\n— '+x.ref+' · Zikr Deen App');return}
  const a=e.target.closest('[data-hai]');if(a){const x=CUR[a.dataset.hai];if(x){try{sessionStorage.setItem('zdAskPre',x.ref+' ki is hadith ka matlab, sanad ka darja aur seekh asaan Hinglish mein batao: '+(x.en||'').slice(0,500))}catch(_){}location.hash='#/ask'}return}
  const h=e.target.closest('[data-hi]');if(h){const n=Number(h.dataset.hi)||h.dataset.hi,x=CUR[n];if(!x)return;h.disabled=true;h.textContent='Soch raha hoon…';
    try{const o=await translate(x.book,[{n,en:x.en}]);x.hi=o[0];const b=$('#hi_'+n);if(b)b.textContent=o[0]}catch(err){h.disabled=false;h.textContent='Dobara try karein';ZD.toast('AI jawab nahin de saka')}}
});
async function fillHi(book,nums){for(const n of nums){const t=await hiGet(book,n);if(t&&CUR[n])CUR[n].hi=t}}

/* ---------- kitaab page ---------- */
let stopFlag=false;
R.hsec=async function(a){
  const id=a[0],sec=a[1],page=Math.max(0,Number(a[2])||0),b=bk(id);if(!b||!sec){location.hash='#/hadith';return}
  let lang=getLang();
  view().innerHTML=top(b[1],'Kitaab '+sec)+'<main>'+seg(lang)+'<div id="hdBox"><p class="muted" style="padding:20px 4px">Load ho raha hai…</p></div></main>';
  const box=$('#hdBox');
  $('#hdSeg').addEventListener('click',e=>{const k=e.target.closest('[data-k]');if(!k)return;setLang(k.dataset.k);R.hsec(a)});
  const mine=()=>location.hash.indexOf('#/hsec/'+id+'/'+sec)===0;
  try{
    let list=[],name='',all=[];const PER=15;
    const O=await offline(id);
    if(O){
      const ia=bySec(O.a)[sec]||[],ue=new Map(((bySec(O.u)[sec])||[]).map(x=>[x[0],x[1]])),en=new Map(((bySec(O.e)[sec])||[]).map(x=>[x[0],x[1]]));
      name=O.e.secs[sec]||O.a.secs[sec]||'';
      all=ia.map(x=>({n:x[0],ar:x[1],ur:ue.get(x[0])||'',en:en.get(x[0])||'',g:x[3],book:id,ref:b[1]+' '+x[0]}));
    }else{
      const [A,U,E]=await Promise.all(['ara-','urd-','eng-'].map(p=>api(p+id+'/sections/'+sec)));
      const um=new Map((U.hadiths||[]).map(x=>[x.hadithnumber,x.text])),em=new Map((E.hadiths||[]).map(x=>[x.hadithnumber,x.text]));
      name=A.metadata&&A.metadata.section?Object.values(A.metadata.section)[0]:'';
      all=(A.hadiths||[]).map(x=>({n:x.hadithnumber,ar:x.text,ur:um.get(x.hadithnumber)||'',en:em.get(x.hadithnumber)||'',g:(x.grades||[]).map(g=>g.grade).filter(Boolean).join(' · '),book:id,ref:b[1]+' '+x.hadithnumber}));
    }
    if(!mine())return;
    list=all.slice(page*PER,page*PER+PER);
    all.forEach(x=>{CUR[x.n]=x});
    await fillHi(id,all.map(x=>x.n));
    const missPage=list.filter(x=>!x.hi).length,missAll=all.filter(x=>!x.hi).length;
    const tools=lang==='hi'?'<div class="card nz-g" id="hdTools">'+(missPage?'<button class="btn sm" id="hiPage">Is page ka Hinglish banayein ('+missPage+')</button> ':'')+(missAll>missPage?'<button class="btn sm ghost" id="hiAll">Poori kitaab ka Hinglish ('+missAll+')</button>':'')+(!missPage&&missAll<=missPage?'<span class="hd-ok">✓ Is page ka Hinglish save hai</span>':'')+'<div class="muted small" id="hiStat" style="margin-top:6px"></div><div class="muted small" style="margin-top:4px">AI tarjuma hai — pakka matlab ke liye Arabic aur kisi aalim se check karein.</div></div>':'';
    box.innerHTML=(name?'<p class="muted small" style="margin:6px 2px 10px">'+esc(name)+' · '+all.length+' hadith'+(O?' · offline':'')+'</p>':'')+tools+
      (list.length?list.map(h=>card(id,h,lang)).join(''):'<p class="muted" style="padding:20px 4px">Is kitaab me hadith nahin mili.</p>')+
      '<div class="nz-nav">'+(page>0?'<a class="btn ghost" href="#/hsec/'+id+'/'+sec+'/'+(page-1)+'">← Pehle</a>':'<span></span>')+(all.length>page*PER+PER?'<a class="btn" href="#/hsec/'+id+'/'+sec+'/'+(page+1)+'">Aage →</a>':(Number(sec)<b[4]?'<a class="btn" href="#/hsec/'+id+'/'+(Number(sec)+1)+'">Agli kitaab →</a>':''))+'</div>';
    window.scrollTo(0,0);
    const run=async items=>{
      const st=$('#hiStat'),btns=$$('#hdTools .btn');stopFlag=false;btns.forEach(x=>x.disabled=true);
      const stop=document.createElement('button');stop.className='btn sm ghost';stop.textContent='Rokein';stop.onclick=()=>{stopFlag=true};$('#hdTools').appendChild(stop);
      let done=0;
      for(let i=0;i<items.length&&!stopFlag&&mine();i+=5){
        const grp=items.slice(i,i+5).filter(x=>x.en);if(!grp.length)continue;
        try{const out=await translate(id,grp.map(x=>({n:x.n,en:x.en})));grp.forEach((x,k)=>{x.hi=out[k];const el=$('#hi_'+x.n);if(el)el.textContent=out[k]});done+=grp.length;if(st)st.textContent=done+' / '+items.length+' ho gaye…'}
        catch(err){if(st)st.textContent='Ruk gaya ('+done+' ho chuke). Thodi der baad dobara dabayein.';break}
        await new Promise(r=>setTimeout(r,1200));
      }
      stop.remove();if(mine()&&st&&done===items.length)st.textContent='✓ Poora ho gaya';btns.forEach(x=>x.disabled=false);
    };
    const hp=$('#hiPage'),ha=$('#hiAll');
    if(hp)hp.addEventListener('click',()=>run(list.filter(x=>!x.hi)));
    if(ha)ha.addEventListener('click',()=>{if(confirm('Poori kitaab ('+missAll+' hadith) ka Hinglish banega. Isme kai minute lag sakte hain aur AI ki free limit kharch hogi. Shuru karein?'))run(all.filter(x=>!x.hi))});
  }catch(e){console.error(e);if(mine())fail(box)}
};
const $$=ZD.$$;
R.hone=async function(a){
  const id=a[0],n=Number(a[1]),b=bk(id);if(!b||!b[5]||!n){location.hash='#/hadith';return}
  let lang=getLang();
  view().innerHTML=top(b[1],'Hadith '+n)+'<main>'+seg(lang)+'<div id="hdBox"><p class="muted" style="padding:20px 4px">Load ho raha hai…</p></div></main>';
  $('#hdSeg').addEventListener('click',e=>{const k=e.target.closest('[data-k]');if(!k)return;setLang(k.dataset.k);R.hone(a)});
  const box=$('#hdBox');
  try{
    let x;const O=await offline(id);
    if(O){const f=L=>L.h.find(r=>r[0]===n);const ar=f(O.a),ur=f(O.u),en=f(O.e);if(!ar)throw new Error('nf');x={n,ar:ar[1],ur:ur?ur[1]:'',en:en?en[1]:'',g:ar[3]}}
    else{const [A,U,E]=await Promise.all(['ara-','urd-','eng-'].map(p=>api(p+id+'/'+n)));const g=r=>(r.hadiths||[])[0];if(!g(A))throw new Error('nf');x={n,ar:g(A).text,ur:g(U)?g(U).text:'',en:g(E)?g(E).text:'',g:(g(A).grades||[]).map(q=>q.grade).filter(Boolean).join(' · ')}}
    x.book=id;x.ref=b[1]+' '+n;x.hi=await hiGet(id,n);CUR[n]=x;
    box.innerHTML=card(id,{n},lang);
  }catch(e){box.innerHTML='<div class="empty"><p><b>Ye hadith number nahin mila.</b></p><p class="small">Number check karein ya internet dekhein.</p></div>'}
};
})();
