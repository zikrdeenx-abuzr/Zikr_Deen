/* Ask Zikr Deen — settings.
   key   : Gemini API key. GitHub build me khud lag jati hai (secret GEMINI_API_KEY se) — yahan type na karein.
   proxy : (optional, zyada safe) apni Netlify function ka URL, jaise https://aapki-site.netlify.app/.netlify/functions/ask
   models: pehla chalega, na chale to agla try hota hai. */
window.ZD_ASK={
  key:'__GEMINI_API_KEY__',
  proxy:'',
  models:['gemini-flash-latest','gemini-2.5-flash','gemini-flash-lite-latest']
};
